import { createSlice } from "@reduxjs/toolkit";

const initialState =  {
    list:[],
}

const slice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        AddItem:(state, action) => {
                state.list = action.payload
            },
     },    
  });


  export default slice.reducer;
  export const { AddItem } = slice.actions