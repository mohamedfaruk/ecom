import React from 'react'
import { useSelector } from 'react-redux'

const Cart = () => {
    const listData = useSelector(state => state.carts.list)
    console.log(listData)
    return (
        <ul>
            {/* <img src={listData.thumbnail} height={150} width={180} />
            <h5>{listData.title}</h5>
            <h6>Price: {`$${listData.price}`}</h6> */}
        {listData.map(items => items.title 
        (
            <li>
            <h5>{items.title}</h5>
            <h6>Price: {`$${items.price}`}</h6>
            </li>
            )           
        )}          
      </ul>
  )
}

export default Cart